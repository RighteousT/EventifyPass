using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EventifyPass.Views.Contacts
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
