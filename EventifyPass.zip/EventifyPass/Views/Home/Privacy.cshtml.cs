using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EventifyPass.Views.Home
{
    public class PrivacyModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
